import UIKit

var greeting = "Hello, playground"

print("Hii",10,12.25)
print(greeting)

//string interpolation
// \(variableName)
var language = "Swift"
print("I dont like \(language)")

var age = 23
print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")

var name = "Matt"
print("Hello, \(name)!")

var year = "Senior"
print("Hello \(name) you are \(age) years old and a \(year) in college.")

print("""
Hello
World!
""")

// \r carriage return
print("Hello All,\rWelcome to Swift programming")

// let is constant
// explicitly declaring the data type
let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")

print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")


var grade = 96
print("Hello \(name) your grade is \(grade)% in", terminator: " " )
print("Fall 2021")


print("The list of numbers are ", terminator: ":" )
print(1,2,3,4,5,6)
print("The new pattern is", terminator: " ")
print(1,2,3,4,5,6, separator: "-")

//declaration of variables
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)
